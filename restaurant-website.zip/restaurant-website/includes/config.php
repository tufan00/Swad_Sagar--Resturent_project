<?php
define('BASE_PATH', dirname(__DIR__));
?>