</main>
    <footer>
        <div class="admin-footer">
            <p>&copy; <?php echo date('Y'); ?> Restaurant Admin Panel. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>